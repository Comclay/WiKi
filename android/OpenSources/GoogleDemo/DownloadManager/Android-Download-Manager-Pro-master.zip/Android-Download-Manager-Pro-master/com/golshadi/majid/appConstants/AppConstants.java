package com.golshadi.majid.appConstants;

public class AppConstants {

	// json process report structure
	public final static String TOKEN = "token";
	public final static String DOWNLOAD_LENGHT = "downloadLength";
	public final static String PERCENT = "PERCENT";
}
