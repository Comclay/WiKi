package com.golshadi.majid.appConstants;

public class DispatchEcode {

	public final static String DOWNLOAD_STARTED	= "DownloadStarted";
	public final static String DOWNLOAD_PAUSED	= "DownloadPaused";
	public final static String DOWNLOAD_PROCESS	= "DownloadProcess";
	public final static String DOWNLOAD_FINISHED = "DownloadFinished";
	
	public final static String DOWNLOAD_REBUILD_START = "DonwloadRebuildStart";
	public final static String DOWNLOAD_REBUILD_FINIESHED = "DonwloadRebuildFinished";

	public final static String DOWNLOAD_COMPLETED = "DownloadCompleted";
	
	public final static String EXCEPTION = "Exception";
	
	public final static String CONNECTION_LOST = "connectionLost";
}
