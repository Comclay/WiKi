package com.golshadi.majid.database.constants;

/**
 * Created by Majid Golshadi on 4/10/2014.
 *
 * all tables names
 */
public final class TABLES {

    public final static String TASKS    = "tasks";
    public final static String CHUNKS   = "chunks";
}
