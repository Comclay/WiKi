# Android-DownloadManager
Android下载管理器，从Android6.0源码中分离出来可独立使用的下载管理器, 用法和特性基本与官方API相同

移除了权限、通知栏、UI相关部分

## 如何使用
    用法和特性基本与官方API相同， 尽可参考系统下载器用法
    
### TODO
    添加更多API测试Demo