package com.asgradle.bintray;

/**
 * Created by bugtags.com on 16/1/25.
 */
public class BintrayAar {
}
