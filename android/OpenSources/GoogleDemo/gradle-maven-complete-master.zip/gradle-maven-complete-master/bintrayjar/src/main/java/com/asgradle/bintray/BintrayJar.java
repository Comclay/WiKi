package com.asgradle.bintray;

public class BintrayJar {
}
