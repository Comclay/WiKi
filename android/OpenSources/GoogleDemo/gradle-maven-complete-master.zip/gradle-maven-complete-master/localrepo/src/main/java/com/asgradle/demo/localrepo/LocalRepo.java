package com.asgradle.demo.localrepo;

/**
 * Created by bugtags.com on 16/1/24.
 */
public class LocalRepo {
}
